module.exports = {
  devServer:{
    port: 8000, // 启动端口
  },
  outputDir: "coupon_web",
  publicPath: '/coupon_web'
}
